# 1.1.5
## Fixes
+ Fix Shy Guy AI. Now he will hunt and Kill, and Ride the Elevator to do it! <3
# 1.1.4
## Updated for v62 & Bug Fixes
+ updated Assemblies to v62
+ Fixed Invisible Shy Guy spawns
+ Fixed Sound Channel Issues (I Hope)
+ Added Support for New Mineshaft Interior (Shy guy on Elevator)
+ Added a New Config Option for v62 to disable Spawn Patching, you ***MUST*** use another mod like LethalQuantities or LethalLevelLoader to add Shy Guy to monsters. This is disabled by default.
# 1.1.3
## Updated for v55
+ This version has been updated and Patched for v55 by TheUnknownCod3r. Please report any issues on their GitHub: https://github.com/TheUnknownCod3r/Scopophobia.
+ Updated KillPlayerRPC
# 1.1.2
## Patched for v50
+ This version has been updated and patched for v50 by TheUnknownCod3r. Please report any issues on their GitHub: https://github.com/TheUnknownCod3r/Scopophobia.
# 1.1.1
## Spawn Config (but fixed now!)
+ Fixed issues with spawn config affecting other enemies. (i very much misunderstood what masked enemy overhaul does)
# 1.1.0
## Spawn Config!
+ Figured out how to make a changelog!
+ Added lots of config options which determine how the Shy Guy spawns (THANK YOU MASKED ENEMY OVERHAUL!!!)
+ Added a switch to the bloody variant of the Shy Guy's material when killing a player (optional)
+ The Shy Guy can now ***Spawn outside***!
+ Fixed issues with rate of spawning.
+ Added config for face trigger grace period (default 0.5s)
+ Added config for other awesome stuff I'm probably forgetting.
# 1.0.2
+ Added the Bloody Textures config and fixed some behavioral issues.
+ Added face trigger range config.
# 1.0.1
+ Fixed multiplayer (forgot to netcode patch LOL).
# 1.0.0
+ Initial official release
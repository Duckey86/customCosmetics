## Version 1.3.1
- fixed a bug where if you stayed on the same moon the multiplier would get reapplied! whoopsie

## Version 1.3.0
- added options to tweak spawn rates for inside versus outside enemies
- added option to turn off spawning of outside or inside enemies
- enemy spawning logic tweaked slightly, find good values

## Version 1.2.0
- reeled back in the intensity on spawnrate
- setting will now impact it more
- can put a decimal spawn rate. below 1 but above 0 will decrease spawnrate

## Version 1.1.0
- improved backend logic on how it works
- will need to crank down this multiplier number

## Version 1.0.0
- inital launch
## Overview
Makes the game more challenging by increasing the spawn rate of enemies! This mod only works if you are the host!

Report Bugs: [Discord Link](https://discord.gg/QTDjSKFCuh)
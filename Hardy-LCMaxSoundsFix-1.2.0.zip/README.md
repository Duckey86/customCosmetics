# This simple mod attempts to fix missing footsteps / missing sounds problem present in Lethal Company (especially modded), by increasing max number of simultaneously playing sounds in Unity engine.

## Credits:

### Yoshify @ Lethal Company Modding Discord server, for the original idea and code snippet

### ppangman @ flaticon.com - for mod icon
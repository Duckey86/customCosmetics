## 1.2.0
- Added config file to finetune audio values. Credits to https://github.com/tonydimalta

## 1.1.0

- Changed mod GUID to make sure it loads before everything else, ensuring compatibility with some audio replacement mods
- Replaced the method to apply audio configuration to more correct one

## 1.0.0

- Initial release
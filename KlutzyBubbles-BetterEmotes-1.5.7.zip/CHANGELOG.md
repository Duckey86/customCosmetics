## Changelog

See [releases](https://github.com/KlutzyBubbles/lc-better-emotes/releases) section on the github page for changelogs
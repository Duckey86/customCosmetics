# ZeroTwo Model v0.1.0
### ZeroTwo skin for Lethal Company

bajojajo
## Changelog
	- v0.1.0
		- Release
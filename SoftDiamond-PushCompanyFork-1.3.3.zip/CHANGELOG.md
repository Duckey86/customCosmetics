# Changelog

<details>

  <summary>1.3.3</summary>

# Additions

  - Added changelog. No features changed this update

</details>
<details>

  <summary>1.3.2</summary>

# Additions

  - You can now use a configurable key to push crewmates.

</details>
<details>

  <summary>1.3.1</summary>

Initial fork release that recompiles the PushCompany by Midge to v73.

</details>
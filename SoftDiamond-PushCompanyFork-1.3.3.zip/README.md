# Push Company

A Lethal Company mod that lets you push your fellow crewmates with an configurable key (E by default)

Comes with configurations for Push Force, Push Range, Push Energy Cost, and Push Cooldown.

Make sure that everyone has the mod or they won't be able to join the host!

Maintained by SoftDiamond with permission. Updated to V73 of Lethal Company!


# HookGenPatcher

Generates [MonoMod.RuntimeDetour.HookGen's](https://github.com/MonoMod/MonoMod) `MMHOOK` file during the [BepInEx](https://github.com/BepInEx/BepInEx) preloader phase. 

Installation:
Put the config folder in the `BepInEx\` folder.
Put the patchers folder in the `BepInEx\` folder.

**This project is not officially linked with BepInEx nor with MonoMod.**

# Latest patchnotes
**0.0.5**  
	- Updated HookGenPatcher main assembly  
	- Fixed config file to work properly in Lethal Company
